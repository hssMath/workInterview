package com.tuling.dynamic.datasource.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Auther: wangyi
 * @Date: 2020/12/12 01:16
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Friend {
    private Long id;
    private String name;
}