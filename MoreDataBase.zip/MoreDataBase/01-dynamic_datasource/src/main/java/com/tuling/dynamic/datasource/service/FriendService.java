package com.tuling.dynamic.datasource.service;

import com.tuling.dynamic.datasource.entity.Friend;

import java.util.List;

/***
 * @Author 徐庶   QQ:1092002729
 * @Slogan 致敬大师，致敬未来的你
 */
public interface FriendService {
    List<Friend> list();

    void save(Friend friend);

}
