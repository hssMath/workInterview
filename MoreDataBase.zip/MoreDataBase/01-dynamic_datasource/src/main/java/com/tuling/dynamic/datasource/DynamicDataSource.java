package com.tuling.dynamic.datasource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * 定义一个继承 AbstractRoutingDataSource 的类，来设置所有的数据库以及默认的数据库。
 */
@Component
@Primary   //将该Bean设置为主要注入Bean
public class DynamicDataSource extends AbstractRoutingDataSource {
    // 当前使用的数据源标识
    public static ThreadLocal<String> dataSourceNameKey = new ThreadLocal<>();

    // 写
    @Autowired
    DataSource dataSource1;
    // 读
    @Autowired
    DataSource dataSource2;


    // 返回当前数据源标识
    @Override
    protected Object determineCurrentLookupKey() {
        return dataSourceNameKey.get();
    }

    @Override
    public void afterPropertiesSet() {
        Map<Object, Object> targetDataSources = new HashMap<>();// 为 targetDataSources 初始化所有数据源
        targetDataSources.put("W", dataSource1);
        targetDataSources.put("R", dataSource2);
        super.setTargetDataSources(targetDataSources);
        super.setDefaultTargetDataSource(dataSource1);// 为 defaultTargetDataSource 设置默认的数据源
        super.afterPropertiesSet();
    }
}
