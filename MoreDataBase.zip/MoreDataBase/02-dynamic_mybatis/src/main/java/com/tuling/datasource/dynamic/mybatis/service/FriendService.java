package com.tuling.datasource.dynamic.mybatis.service;


import com.tuling.datasource.dynamic.mybatis.entity.Friend;

import java.util.List;

/***
 * @Author 徐庶   QQ:1092002729
 * @Slogan 致敬大师，致敬未来的你
 */
public interface FriendService  {

    List<Friend> list();

    // 保存-- 写库
    void saveW(Friend friend);

    // 保存-- 读库
    void saveR(Friend friend);

    void save(Friend friend);

    // 读--写库
    void saveAll(Friend friend) throws Exception;

    void saveAllR(Friend friend);
}
