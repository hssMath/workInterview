package com.tuling.datasource.dynamic.mybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableAspectJAutoProxy(exposeProxy = true)     // @EnableAspectJAutoProxy 开启基于注解的 Aop 模式
@EnableTransactionManagement                    // @EnableTransactionManagement 开启 spring 事务
public class DynamicMybatisApplication {
    public static void main(String[] args) {
        SpringApplication.run(DynamicMybatisApplication.class, args);
    }
}