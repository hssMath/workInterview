package com.tuling.datasource.dynamic.mybatis.mapper.write;


import com.tuling.datasource.dynamic.mybatis.entity.Friend;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: wangyi
 * @Date: 2020/12/12 01:16
 * @Description: 
 */
public interface WFriendMapper {
    @Select("SELECT * FROM Friend")
    List<Friend> list();

    @Insert("INSERT INTO  friend(`name`) VALUES (#{name})")
    void save(Friend friend);
}