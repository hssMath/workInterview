package com.tuling.datasource.dynamic.mybatis.aop;

import java.lang.annotation.*;

@Target(ElementType.METHOD)         //自定义注解可以被使用的位置：包、类、方法（普通方法、构造方法）、属性。
@Retention(RetentionPolicy.RUNTIME) //注解保留的位置：source、class、runtime
@Documented
public @interface MultiTransactional {
    String[] value() default {};
}
