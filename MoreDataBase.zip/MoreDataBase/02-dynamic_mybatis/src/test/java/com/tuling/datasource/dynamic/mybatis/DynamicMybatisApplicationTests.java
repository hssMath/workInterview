package com.tuling.datasource.dynamic.mybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicMybatisApplicationTests {

    @Test
    void contextLoads() {
    }

}
