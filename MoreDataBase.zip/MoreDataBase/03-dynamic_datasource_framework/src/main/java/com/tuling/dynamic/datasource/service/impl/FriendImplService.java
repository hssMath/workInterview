package com.tuling.dynamic.datasource.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.dynamic.datasource.annotation.DSTransactional;
import com.tuling.dynamic.datasource.entity.Frend;
import com.tuling.dynamic.datasource.mapper.FriendMapper;
import com.tuling.dynamic.datasource.service.FriendService;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/***
 * @Author 徐庶   QQ:1092002729
 * @Slogan 致敬大师，致敬未来的你
 */
@Service
public class FriendImplService implements FriendService {

    @Autowired
    FriendMapper friendMapper;


    @Override
    @DS("slave")  // 从库， 如果按照下划线命名方式配置多个  ， 可以指定前缀即可（组名）
    public List<Frend> list() {
        return friendMapper.list();
    }

    @Override
    @DS("master")
    public void save(Frend frend) {
        friendMapper.save(frend);
    }

    /*
    本地事务：使用@DSTransactional即可，不能和Spring@Transactional混用！
         1 在最外层的方法添加 @DSTransactional，底下调用的各个类该切数据源就正常使用DS切换数据源即可。
         2 如AService调用BService和CService的方法，A,B,C分别对应不同数据源。
    */
    @DS("master")
    @DSTransactional
    public void saveAll(){
        // 执行多数据源的操作
    }

}
