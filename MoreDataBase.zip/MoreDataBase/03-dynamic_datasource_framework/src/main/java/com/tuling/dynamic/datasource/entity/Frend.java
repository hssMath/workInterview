package com.tuling.dynamic.datasource.entity;

import lombok.Data;

/**
 * @Auther: wangyi
 * @Date: 2020/12/12 01:16
 * @Description:
 */
@Data
public class Frend  {
    private Long id;

    private String name;

}