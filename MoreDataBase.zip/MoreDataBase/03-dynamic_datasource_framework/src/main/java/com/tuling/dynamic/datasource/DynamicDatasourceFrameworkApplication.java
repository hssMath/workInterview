package com.tuling.dynamic.datasource;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication
@EnableRetry
@MapperScan("com.tuling.dynamic.datasource.mapper")
public class DynamicDatasourceFrameworkApplication {

    public static void main(String[] args) {
        SpringApplication.run(DynamicDatasourceFrameworkApplication.class, args);
    }

}
