package com.tuling.dynamic.datasource.controller;

import com.tuling.dynamic.datasource.service.RetryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;


@RestController
@RequestMapping("retry")
public class RetryController {
    @Resource
    private RetryService retryService;

    @GetMapping(value = "test")
    public void test(String code) throws Exception {
        retryService.test(0);
    }
}
